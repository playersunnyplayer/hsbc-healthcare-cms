<?php
ob_start();
session_start();
$adminId=$_SESSION['aid'];
include_once("configuration/connect.php");
include_once("configuration/functions.php");
if (isset($_GET['web'])&&$_GET['web']!='') {
$wid=base64_decode($_GET['web']);
$_SESSION['web']=$wid;
}
if(isset($_SESSION["aid"])) {
if(isLoginSessionExpired()) {
header("Location:logout.php");
}
}
$webId=$_SESSION['web'];
checkIntrusion($adminId);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Add Page| <?php echo getSiteTitle($webId); ?> </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include 'css.php'; ?>
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
<style>
#sticky-div {
   position : fixed;
 /*bottom:0;*/

}
</style>
<script>
$counter =0;
//$a =0;
	// add code
		function addCode(ele)
		{
			$button = $(ele);
			// increment
			$counter += 1;
			$button.closest('tr').before('<tr><td><div  class="mb-3 col-lg-12"><label for="name">Title</label><input type="text"  name="pp['+$counter+'][title]" class="form-control"/></div><div  class="mb-3 col-lg-12"><label for="name">Content</label><textarea class="form-control" id="editor'+$counter+'" placeholder="Content" name="pp['+$counter+'][content]"></textarea></div><div style="text-align:right"><button class="btn btn-danger btn-sm remove_code"  type="button" onClick="remove(this)">Remove section</button></div></td></tr>');
			var a="editor"+$counter;
			CKEDITOR.replace(a);
		}
		function remove(ele)
		{
			$button = $(ele);
			$button.closest('tr').remove();
			return false;
		}
</script>

</head>
<body >
<!-- Begin page -->
<div id="layout-wrapper">
<?php include 'header.php'; ?>
<!-- ========== Left Sidebar Start ========== -->
<?php include 'leftmenu.php'; ?>
<!-- Left Sidebar End -->
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
    <div class="row">
<div class="col-12">
<div class="page-title-box d-sm-flex align-items-center justify-content-between">
<h4 class="mb-sm-0 font-size-18"> </h4>
<div class="page-title-right">
<div class="dropdown">
<button class="btn btn-outline-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
<i class="fas fa-globe"></i> <?php echo getSiteTitle($webId)?> <i class="mdi mdi-chevron-down"></i>
</button>
<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
<?php $qry=mysqli_query($con,"select * from websiteheader where assign_to='$adminId'and id!=$webId");
$num=mysqli_num_rows($qry);
if($num>0){
while ($fetch=mysqli_fetch_array($qry)) {
?>
<li class="dropdown-item"><a href="dashboard.php?web=<?php echo base64_encode($fetch['id']) ?>" key="t-product-detail"> <?php echo $fetch['site_name'] ?></a></li>
<?php }} ?>
</div>
</div>
</div>
</div>
</div>
</div>
	<div class="row">
				<div class="col-xl-12">
						<div class="card overflow-hidden">
								<div class="">
										<div class="row ">
												<div class="col-7">
														<div class=" p-3">
																<h5 class="text-primary" style="margin:20px 0 30px">Welcome <?php echo getAdminName($adminId) ?> !</h5>
																<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur varius, odio quis vestibulum hendrerit, nisl neque venenatis purus, non scelerisque nulla risus at nisl. Proin pretium, justo quis ultricies vehicula, nisi mi condimentum ar Proin pretium, justo quis ultricies vehicula, nisi mi condimentum arProin pretium, justo quis ultricies vehicula, nisi mi condimentum arProin pretium, justo quis ultricies vehicula, nisi mi condimentum ar </p>

														<a href="addpage.php" ><button class="btn-primary btn-sm btn">Create New Page</button></a>



														</div>
												</div>
												<div class="col-5 align-self-end">
														<img src="assets/images/profile-img.png" alt="" class="img-fluid">
												</div>
										</div>
								</div>
							</div>
						</div>
</div>
</div>
</div>
</div>
</div>
<?php include 'script.php'; ?>

</body>
</html>
