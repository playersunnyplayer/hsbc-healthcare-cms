
<div class="vertical-menu">

    <div data-simplebar class="h-100">
      <div style="text-align:center;width:100px;height:100px;margin:20px auto 10px;overflow:hidden">
<img src="assets/images/logo.png" alt="" style="width:100px">
</div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <!--<li class="menu-title" key="t-menu">Menu</li>-->
                <li ><a href="dashboard.php" class="waves-effect"><i class="bx bxs-dashboard"></i><span key="t-dashboards">Dashboard</span></a></li>

  <li><a href="settings.php" key="t-products">  <i class="bx bx-cog"></i>Settings</a></li>
  <li><a href="logout.php" key="t-product-detail">  <i class="bx bx-lock"></i>Log Out</a></li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
