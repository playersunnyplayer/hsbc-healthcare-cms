<?php
ob_start();
session_start();
$adminId=$_SESSION['aid'];
include_once("configuration/connect.php");
include_once("configuration/functions.php");
if(isset($_SESSION["aid"])) {
	if(isLoginSessionExpired()) {
		header("Location:logout.php");
	}
}
checkIntrusion($adminId);
$date=date('d-m-Y h:i:sa');
if(isset($_POST['update'])){
	extract($_POST);
	$id=$_POST['hidid'];
	$crmname=$_POST['name'];
	$crmtitle=$_POST['contact'];
	$crmtagline=$_POST['tagline'];
	$slug=$_POST['slug'];
	$color=$_POST['color'];
	$emp_id=$_POST['emp_id'];
	$filename = $_FILES['image2']['name'];
  $valid_ext = array('png','jpeg','jpg','ico');
   $location2="../assets/img/".$filename;
  $location = "../assets/img/".$filename;
  $file_extension = pathinfo($location, PATHINFO_EXTENSION);
  $file_extension = strtolower($file_extension);
  if(in_array($file_extension,$valid_ext)){
    compressImage($_FILES['image']['tmp_name'],$location,60);
	  }else{
    echo "Invalid file type.";
	  }

	if($filename!=''&& $filename!=''){
	$sqlQry="UPDATE `websiteheader` SET `site_name`='$crmname',`site_logo`='$filename',`site_contact`='$crmtitle',
	`site_tagline`='$crmtagline',`status`='1',`color`='$color',`assign_to`='$emp_id',`slug`='$slug',`up_id`='$adminId',`date`='$date'
	 WHERE `id` = '$id'";
 }else{
	 $sqlQry="UPDATE `websiteheader` SET `site_name`='$crmname',`site_contact`='$crmtitle',`site_tagline`='$crmtagline',`status`='1',`color`='$color',`assign_to`='$emp_id',`slug`='$slug',`up_id`='$adminId',`date`='$date'  WHERE `id` = '$id'";

 }
	$execQry=mysqli_query($con,$sqlQry);
	if($execQry){
		header("location:company.php?msg=ups");
	}else{
		header("location:company.php?msg=upf");
	}
}
if(isset($_POST['addcomp'])){
	extract($_POST);
	$crmname=$_POST['name'];
	$crmtitle=$_POST['contact'];
	$crmtagline=$_POST['tagline'];
	$slug=$_POST['slug'];
	$color=$_POST['color'];
	$emp_id=$_POST['emp_id'];
	$filename = $_FILES['image']['name'];
  $valid_ext = array('png','jpeg','jpg','ico');
   $location2="../assets/img/".$filename;
  $location = "../assets/img/".$filename;
  $file_extension = pathinfo($location, PATHINFO_EXTENSION);
  $file_extension = strtolower($file_extension);
  if(in_array($file_extension,$valid_ext)){
    compressImage($_FILES['image']['tmp_name'],$location,60);
	  }else{
    echo "Invalid file type.";
	  }
if(checkCompanySlug($slug)==0){
	$sqlQry="INSERT INTO `websiteheader`(`id`, `site_name`, `slug`,`site_logo`, `site_contact`, `site_tagline`, `color`, `emp_id`, `assign_to`, `up_id`, `date`, `status`)
	 VALUES (NULL,'$crmname','$slug','$filename','$crmtitle','$crmtagline','$color','$adminId','$emp_id','$adminId','$date','1')";
	$execQry=mysqli_query($con,$sqlQry);
	if($execQry){
		header("location:company.php?msg=ups");
	}else{
		header("location:company.php?msg=upf");
	}
}else{
	header("location:addcompany.php?msg=usr");
}
}
if(isset($_GET['msg'])&&$_GET['msg']!=''){
	$msg=$_GET['msg'];

	switch($msg){
	case 'ins':
		$msg='Comapny  has been added Successfully !!';
		$class='success';
	break;

	case 'inf':
		$msg='Company not inserted Successfully !!';
		$class='danger';
	break;
	case 'ups':
		$msg='Company data updated Successfully !!';
		$class='success';
	break;

	case 'usr':
		$msg='Company slug is not avilable !!';
		$class='danger';
	break;
	case 'default' :
		$msg='';
		break;
	}
	}
?>
<!doctype html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <title>Add Company </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include 'css.php'; ?>
				 <link href="assets/libs/spectrum-colorpicker2/spectrum.min.css" rel="stylesheet" type="text/css">
				<script src="assets/libs/jquery/jquery.min.js"></script>

				<script>
function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#pimage')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
function checkreslug(code) {
	if(code.length>=4){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		var b=this.responseText;
		var s=b.split('#');
		if(s[0]==1){
			document.getElementById("cod").innerHTML =s[1];
			document.getElementById("cod").style.color = "red";

			return false;
		}else{
			document.getElementById("cod").innerHTML ='Avilable';
	        document.getElementById("cod").style.color = "green";

		}

    }
  };
  xhttp.open("POST", "checkslug.php?code="+code, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send();

}
}

</script>
    </head>
    <body >
        <!-- Begin page -->
        <div id="layout-wrapper">
        <?php include 'header.php'; ?>
            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'leftmenu.php'; ?>
            <!-- Left Sidebar End -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        	<div class="row">
										<div class="col-12">
												<div class="page-title-box d-sm-flex align-items-center justify-content-between">
														<h4 class="mb-sm-0 font-size-18">Add Company  </h4>
														<div class="page-title-right">
														<!--<a href="addpage.php"	<button type="button" class="btn btn-primary btn-sm waves-effect waves-light">Add Page</button></a>-->

																															 </div>
												</div>
										</div>
								</div>
									<div class="row">
										<div class="col-12">
								<?php if($msg!=''){ ?>
								<div class="alert alert-<?php echo $class ?> alert-dismissible fade show" role="alert">
															<?php echo $msg; ?>
														 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
												 </div>
											<?php } ?>
											</div>
											</div>
										
					         
					                                         <div class="row">
                            <div class="col-xl-12">
                                <div class="card overflow-hidden">
                                    <div class="">
                                        <div class="row">
                                            <div class="col-7">
                                                <div class="p-3">
                                             																		<form  id="myform" action="" method="post" enctype="multipart/form-data">
																										<?php if (isset($_GET['cmp_id'])&&$_GET['cmp_id']!='') {
																										$cid=base64_decode($_GET['cmp_id']);
																										$qry=mysqli_query($con,"select * from websiteheader where id='$cid'");
																										$hqry=mysqli_fetch_array($qry);?>
																										<input type="hidden" name="hidid" value="<?php echo $hqry['id'] ?>">
																		 <div class="row">
																		      <div class="col-md-6">
																						 <div class="mb-3">
																								 <label for="formrow-name-input" class="form-label">Name <span style="color:red">*</span></label>
																								 <input onKeyUp="fillPrintableName()" type="text" class="form-control" id="name" name="name" value="<?php echo $hqry['site_name'] ?>">
																						 </div>
																						 <div class="mb-3">
																							 <label for="TagLine" class="form-label"> Slug(Compnay's User name) </label>
																							 <input style="text-transform:lowercase"  type="text" class="form-control" id="slug" name="slug" value="<?php echo $hqry['slug'] ?>" >
																					 </div>
																						 	 <div class="mb-3">
																								 <label for="TagLine" class="form-label"> TagLine </label>
																								 <input type="text" class="form-control" id="tagline" name="tagline" value="<?php echo $hqry['site_tagline'] ?>" >
																						 </div>
																						 <div class="mb-3">
																								 <label for="formrow-inputContact" class="form-label"> Contact <span style="color:red">*</span></label>
																								 <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $hqry['site_contact'] ?>" >
																						 </div>

																				 </div>


																				 <div class="col-md-6">
																						<div class="mb-3">
																			 				<label for="formrow-logo-input" class="form-label"> Logo <span style="color:red">*</span></label><br>
																							<div style="width:100%;margin:0px auto 20px;overflow:hidden;padding:10px;border:1px dashed #ddd;text-align:center">
																				<img id="pimage" src="patientZoneCMSAdmin/src/assets/img/<?php echo $hqry['site_logo'] ?>"  alt="" style="width:70px">
																				</div>
																							<input style="margin-top:10px" class="form-control form-control" id="image2" type="file" name="image2" onchange="readURL(this);" value="<?php echo $hqry['site_logo'] ?>">
																			 		</div>

																					<div class="mb-3">
																							 <label class="form-label">Color</label>
																							 <input type="text" name="color" required class="form-control" id="colorpicker-default" value="<?php echo $hqry['color'] ?>">
																				        </div>
																				 <div class="mb-3">
																						 <label for="formrow-inputContact" class="form-label"> Assign To <span style="color:red">*</span></label>
																						 <select class="form-control" name="emp_id" id="emp_id">
																							 <option value="0">Select Employee</option>
																							 <?php $qry=mysqli_query($con,"select * from admin where status='1'");
																							 $num=mysqli_num_rows($qry);
																							 if ($num>0) {
																								 while ($emp=mysqli_fetch_array($qry)) {?>
																									 <option <?php if ($emp['id']==$hqry['assign_to']) { ?>selected <?php } ?>value="<?php echo $emp['id'] ?>"><?php echo $emp['firstname'].' '.$emp['lastname'] ?></option>
																								<?php }}else{ ?>
																						 <option value="0">--No Record found--</option>
																							<?php } ?>
																						 </select>
																				 </div>
																				 </div>

																		 </div>
																		 <div><button type="submit" name="update" class="btn btn-primary btn-sm w-md">Update Company</button></div>
																	 <?php }else{ ?>
																		 <div class="row">
																					<div class="col-md-6">
																						 <div class="mb-3">
																								 <label for="formrow-name-input" class="form-label">Name <span style="color:red">*</span></label>
																								 <input onKeyUp="fillPrintableName()" type="text" class="form-control" id="name" name="name" value="<?php echo $hqry['site_name'] ?>">
																						 </div>
																						 <div class="mb-3">
																							 <label for="TagLine" class="form-label"> Slug(Compnay's User name) <span style="color:red">*</span></label>
																							 <input style="text-transform:lowercase" onKeyup="checkreslug(this.value)" type="text" class="form-control" id="slug" name="slug" value="<?php echo $hqry['site_tagline'] ?>" >
																							 <span  style="color:red"><small id="cod"><?php echo $rftxt?></small></span>
																					 </div>
																							 <div class="mb-3">
																								 <label for="TagLine" class="form-label"> TagLine </label>
																								 <input type="text" class="form-control" id="tagline" name="tagline" value="<?php echo $hqry['site_tagline'] ?>" >
																						 </div>
																						 <div class="mb-3">
																								 <label for="formrow-inputContact" class="form-label"> Contact <span style="color:red">*</span></label>
																								 <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $hqry['site_contact'] ?>" >
																						 </div>

																				 </div>


																				 <div class="col-md-6">
																						<div class="mb-3">
																							<label for="formrow-logo-input" class="form-label"> Logo <span style="color:red">*</span></label><br>
																							<div style="width:100%;margin:0px auto 20px;overflow:hidden;padding:10px;border:1px dashed #ddd;text-align:center">
																				<img id="pimage" src="patientZoneCMSAdmin/src/assets/img/<?php echo $hqry['site_logo'] ?>"  alt="" style="width:70px">
																				</div>
																							<input style="margin-top:10px" class="form-control form-control" id="image" type="file" name="image" onchange="readURL(this);">
																					</div>

																				 <div class="mb-3">
																						 <label for="formrow-inputContact" class="form-label"> Assign To <span style="color:red">*</span></label>
																						 <select class="form-select" name="emp_id" id="emp_id">
																							 <option value="">Select Employee</option>
																							 <?php $qry=mysqli_query($con,"select * from admin where status='1'");
																							 $num=mysqli_num_rows($qry);
																							 if ($num>0) {
																								 while ($emp=mysqli_fetch_array($qry)) {?>
																									 <option <?php if ($emp['id']=='1') { ?>selected <?php } ?>value="<?php echo $emp['id'] ?>"><?php echo $emp['firstname'].' '.$emp['lastname'] ?></option>
																								<?php }}else{ ?>
																						 <option value="0">--No Record found--</option>
																							<?php } ?>
																						 </select>
																				 </div>
																				 
																					<div class="mb-3">
																							 <label for="color" class="form-label">Color</label>
																							 <input type="text" name="color" required class="form-control" id="colorpicker-default" value="<?php echo $hqry['color'] ?>"/>
																				 </div>
																				 </div>

																		 </div>
																		 <div><button type="submit" name="addcomp" class="btn btn-primary btn-sm w-md">Add </button> <button onclick="goBack()" type="button" name="cancel" class="btn btn-outline-primary btn-sm w-md">Cancel </button></div>
																	 <?php } ?>
																 </form>
                                                </div>
                                            </div>
                                            <div class="col-5 align-self-end">
                                                <img src="assets/images/verification-img.png" alt="" class="img-fluid">
                                            </div>
                                        </div>
                                    </div>

									</div>
									</div>
									</div>
                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->
  <?php include 'script.php'; ?>
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script type="text/javascript">
function goBack() {
  window.history.go(-1);
}
function fillPrintableName(){
	var fname=document.getElementById('name').value;	
var c=fname.replace(/\s/g, '-')
	var nameoncard =document.getElementById('slug');
	nameoncard.value=c;	
}
$(document).ready(function() {

$('#myform').validate({
	rules: {
			name: "required",
			slug:"required",
			contact: {
		required: true,
		 number: true,
		 minlength: 10,
		 maxlength: 10
	 },
	 image: "required",
	 emp_id:"required"
	},
	messages: {
		name: "Please enter name",
slug:"Please enter slug",
		contact: {
			required: "Please enter contact no",
			minlength: "Please enter 10 digit contact no",
			maxlength: "Please enter 10 digit contact no"
		},
		image: "Please select logo",
		emp_id:"Plese select employee"
	},
	submitHandler: function(form) { // for demo
		form.submit();
	}
});

});
</script>
	<script src="assets/libs/select2/js/select2.min.js"></script>

	<script src="assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>


	<!-- form advanced init -->
	<script src="assets/js/pages/form-advanced.init.js"></script>
    </body>
</html>
