<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <!--<script>document.write(new Date().getFullYear())</script> © Trust.-->
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                  <span class="text-muted">  Powered By</span> <img src="Picture3.png" alt="Trust" height="37">
                </div>
            </div>
        </div>
    </div>
</footer>
