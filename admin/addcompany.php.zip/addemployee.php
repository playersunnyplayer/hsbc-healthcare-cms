<?php
ob_start();
session_start();
$adminId=$_SESSION['aid'];
include_once("configuration/connect.php");
include_once("configuration/functions.php");
if(isset($_SESSION["aid"])) {
if(isLoginSessionExpired()) {
header("Location:logout.php");
}
}
checkIntrusion($adminId);
$date=date('d-m-Y h:i:sa');
if(isset($_POST['addemp'])){
extract($_POST);
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$empid=$_POST['empid'];
$email=$_POST['email'];
$uname=$_POST['uname'];
$pwd=md5($_POST['pwd']);
$sts=$_POST['sts'];
$sqlQry="INSERT INTO `admin`(`id`,`emp_id`, `firstname`, `lastname`, `username`, `password`, `email`,`status`) VALUES (NULL,'$empid','$fname','$lname','$uname','$pwd','$email','$sts')";
$execQry=mysqli_query($con,$sqlQry);
if($execQry){
header("location:employee.php?msg=ins");
}else{
header("location:addemployee.php?msg=upf");
}
}
if(isset($_POST['updateemp'])){
extract($_POST);
$id=$_POST['hidid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$empid=$_POST['empid'];
$email=$_POST['email'];
$uname=$_POST['uname'];
$pwd=md5($_POST['pwd']);
$sts=$_POST['sts'];
$sqlQry="UPDATE `admin` SET `firstname`='$fname',`lastname`='$lname',`password`='$pwd',`email`='$email',`status`='$sts',`emp_id`='$empid' WHERE `id`='$id'";
$execQry=mysqli_query($con,$sqlQry);
if($execQry){
header("location:employee.php?msg=ups");
}else{
header("location:addemployee.php?msg=upf");
}
}
if(isset($_GET['msg'])&&$_GET['msg']!=''){
$msg=$_GET['msg'];

switch($msg){
case 'ins':
$msg='Employee has been added Successfully !!';
$class='success';
break;

case 'inf':
$msg='Profile data not inserted Successfully !!';
$class='danger';
break;
case 'ups':
$msg='Employee updated Successfully !!';
$class='success';
break;

case 'upf':
$msg='Profile data not updated Successfully !!';
$class='danger';
break;
case 'default' :
$msg='';
break;

}
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Profile  </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include 'css.php'; ?>
<link href="assets/libs/spectrum-colorpicker2/spectrum.min.css" rel="stylesheet" type="text/css">
<script src="assets/libs/jquery/jquery.min.js"></script>
<style media="screen">
.field-icon {
	text-align:center;
float: right;
padding-top: 10px;
padding-right: 10px;
padding-left: 10px;
background-color: #eff2f7;
border: 1px solid #ced4da;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
margin-top: -36px;
height:35px;
width: 40px;
position: relative;
z-index: 2;
cursor: pointer;
}
</style>
<script>
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#pimage')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}
</script>
</head>
<body >
<!-- Begin page -->
<div id="layout-wrapper">
<?php include 'header.php'; ?>
<!-- ========== Left Sidebar Start ========== -->
<?php include 'leftmenu.php'; ?>
<!-- Left Sidebar End -->
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
<div class="row">
<div class="col-12">
<div class="page-title-box d-sm-flex align-items-center justify-content-between">
<h4 class="mb-sm-0 font-size-18">Add Employee  </h4>
<div class="page-title-right">
<!--<a href="addpage.php"	<button type="button" class="btn btn-primary btn-sm waves-effect waves-light">Add Page</button></a>-->

</div>
</div>
</div>
</div>
<div class="row">
                            <div class="col-xl-12">

<?php if($msg!=''){ ?>
<div class="alert alert-<?php echo $class ?> alert-dismissible fade show" role="alert">
<?php echo $msg; ?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>
</div>
</div>


<div class="row">
                            <div class="col-xl-12">
                                <div class="card overflow-hidden">
                                    <div class="">
                                        <div class="row">
                                            <div class="col-7">
                                                <div class="p-3">
                                             <form  id="myform" action="" method="post" enctype="multipart/form-data">
	<?php if (isset($_GET['emp_id'])&&$_GET['emp_id']!='') {
	$eid=base64_decode($_GET['emp_id']);
	$qry=mysqli_query($con,"select * from admin where id='$eid'");
	$fetch2=mysqli_fetch_array($qry);?>
<input type="hidden" name="hidid" value="<?php echo $fetch2['id'] ?>">
<div class="row">
<div class="col-md-6">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">First Name <span style="color:red">*</span></label>
<input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fetch2['firstname'] ?>">
</div>
</div>
<div class="col-md-6">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">Last Name </label>
<input type="text" class="form-control" id="lname" name="lname" value="<?php echo $fetch2['lastname'] ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">Employee Id <span style="color:red">*</span></label>
<input type="text" class="form-control" id="empid" name="empid" value="<?php echo $fetch2['emp_id'] ?>">
</div>
</div>
<div class="col-md-6">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">Email <span style="color:red">*</span></label>
<input type="email" class="form-control" id="email" name="email" value="<?php echo $fetch2['email'] ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-4">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">User Name <span style="color:red">*</span></label>
<input type="text" class="form-control" readonly id="uname" name="uname" value="<?php echo $fetch2['username'] ?>">
</div>
</div>
<div class="col-md-4">
<div class="mb-3">
<label for="formrow-name-input" class="form-label">Password <span style="color:red">*</span></label>
<input id="password-field" type="password" class="form-control" id="pwd" name="pwd" value="<?php echo $fetch2['password'] ?>">
<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>

</div>
</div>

<div class="col-md-4">
<div class="mb-3">
	<label for="order">Status</label>
	<select class="form-control" name="sts" id="sts">
		<option <?php if ($fetch2['status']=='1') { ?>selected <?php } ?>value="1">Active</option>
		<option <?php if ($fetch2['status']=='0') { ?>selected <?php } ?>value="0">Deactive</option>
	</select>
</div>
</div>
</div>
<div >
<button type="submit" name="updateemp" class="btn btn-primary btn-sm w-md">Update</button>
</div>

<?php }else{ ?>
	<div class="row">
	<div class="col-md-6">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">First Name <span style="color:red">*</span></label>
	<input type="text" class="form-control" id="fname" name="fname" value="">
	</div>
	</div>
	<div class="col-md-6">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">Last Name </label>
	<input type="text" class="form-control" id="lname" name="lname" value="">
	</div>
	</div>
	</div>
	<div class="row">
	<div class="col-md-6">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">Employee Id <span style="color:red">*</span></label>
	<input type="text" class="form-control" id="empid" name="empid" value="">
	</div>
	</div>
	<div class="col-md-6">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">Email <span style="color:red">*</span></label>
	<input type="email" class="form-control" id="email" name="email" value="">
	</div>
	</div>
	</div>
	<div class="row">
	<div class="col-md-4">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">User Name <span style="color:red">*</span></label>
	<input type="text" class="form-control" id="uname" name="uname" value="">
	</div>
	</div>
	<div class="col-md-4">
	<div class="mb-3">
	<label for="formrow-name-input" class="form-label">Password <span style="color:red">*</span></label>
	<input id="password-field" type="password" class="form-control" id="pwd" name="pwd" value="">
	<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
	</div>
	</div>
	
	<div class="col-md-4">
	<div class="mb-3">
		<label for="order">Status</label>
		<select class="form-control" name="sts" id="sts">
			<option value="1">Active</option>
			<option value="0">Deactive</option>
		</select>
	</div>
	</div>
	</div>
	<div >
	<button type="submit" name="addemp" class="btn btn-primary btn-sm w-md">Add</button>
	</div>
<?php } ?>
</form>
                                                </div>
                                            </div>
                                            <div class="col-5 align-self-end">
                                                <img src="assets/images/verification-img.png" height="330" width="330" class="img-fluid">
                                            </div>
                                        </div>
                                    </div>

									</div>
									</div>
									</div>
</div>
<!-- container-fluid -->
</div>

</div>
<!-- end main content-->
</div>
<!-- END layout-wrapper -->
<?php include 'script.php'; ?>
<script type="text/javascript">
$(".toggle-password").click(function() {
$(this).toggleClass("fa-eye fa-eye-slash");
var input = $($(this).attr("toggle"));
if (input.attr("type") == "password") {
input.attr("type", "text");
} else {
input.attr("type", "password");
}
});
</script>
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {
$('#myform').validate({
rules: {
fname: "required",
empid: "required",
email: {
	required: true,
	email: true
},
uname: "required",
pwd: {
						required: true, minlength: 5
			},
repwd: {
						required: true, minlength: 5, equalTo: "#pwd",
			}
},
messages: {
fname: "Please enter name",
empid: "Please enter employee id",
email: "Please enter email",
uname: "Please enter username",
pwd:{
	required:"Please enter new password",
	minlength:"Password should be minimum 5 digit."
} ,
repwd:{
	required: "Please enter retype  password",
	minlength: "Password should be minimum 5 digit.",
	equalTo: "Please should be the same as new password"
}
},
submitHandler: function(form) { // for demo
form.submit();
}
});

});
</script>
<script src="assets/libs/select2/js/select2.min.js"></script>
<script src="assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
<!-- form advanced init -->
<script src="assets/js/pages/form-advanced.init.js"></script>
</body>
</html>
